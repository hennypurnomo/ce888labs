Vehicles.py
This file is used to retrieve data from vehicles.py and create a scatterplots and histogram. The results will be saved in png and pdf file. It also print the result of mean, median, var, std, and Median Absolute Deviation (MAD). In order to deal with some missing values in the data, those values was converted into n/a. 
